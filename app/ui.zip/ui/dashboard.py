﻿"""
Alpha Engine Dashboard - Main UI Component

This module provides the main dashboard interface for the Alpha Engine v3.0.
It follows Single Responsibility Principle by separating concerns:
- Configuration and initialization
- Data fetching and state management  
- UI rendering and layout
- Component-specific display functions

Author: Alpha Engine Team
Version: 3.0
"""

import streamlit as st
from typing import Optional, Dict, Any, List

from app.ui.middle.dashboard_service import DashboardService, arrow

# Optional dependency for auto-refresh functionality
try:
    from streamlit_autorefresh import st_autorefresh  # type: ignore
except Exception:  # pragma: no cover
    st_autorefresh = None

# ============================================================================
# CONFIGURATION & INITIALIZATION
# ============================================================================

# Page configuration
st.set_page_config(
    layout="wide",
    page_title="Alpha Engine Dashboard",
    page_icon="🚀"
)

# Constants
DEFAULT_DB_PATH = "data/alpha.db"
DEFAULT_MIN_PREDICTIONS = 5
DEFAULT_SIGNALS_LIMIT = 25
DEFAULT_REFRESH_INTERVAL = 2000


@st.cache_resource
def get_dashboard_service(db_path: str) -> DashboardService:
    """
    Initialize and cache the dashboard service instance.
    
    Args:
        db_path: Path to the SQLite database
        
    Returns:
        DashboardService: Cached service instance
    """
    return DashboardService(db_path=db_path)


# ============================================================================
# DATA FETCHING & STATE MANAGEMENT
# ============================================================================

class DashboardState:
    """Manages dashboard state and data fetching operations."""
    
    def __init__(self, service: DashboardService):
        self.service = service
        self.tenant_id: Optional[str] = None
        self.ticker: Optional[str] = None
        self.min_predictions: int = DEFAULT_MIN_PREDICTIONS
        self.signals_limit: int = DEFAULT_SIGNALS_LIMIT
        self.filter_signals_to_ticker: bool = True
        
        # Data cache
        self._champions: Optional[Dict[str, Any]] = None
        self._challengers: Optional[Dict[str, Any]] = None
        self._consensus: Optional[Any] = None
        self._loop_health: Optional[Any] = None
        self._signals: Optional[List[Any]] = None
    
    def refresh_data(self):
        """Refresh all dashboard data from the service."""
        if not self.tenant_id:
            return
            
        self._champions = self.service.get_champions(
            tenant_id=self.tenant_id, 
            min_predictions=self.min_predictions
        )
        self._challengers = self.service.get_challengers(
            tenant_id=self.tenant_id, 
            min_predictions=self.min_predictions
        )
        
        if self.ticker:
            self._consensus = self.service.get_latest_consensus(
                tenant_id=self.tenant_id, 
                ticker=self.ticker
            )
        
        self._loop_health = self.service.get_loop_health(tenant_id=self.tenant_id)
        
        ticker_filter = self.ticker if (self.filter_signals_to_ticker and self.ticker) else None
        self._signals = self.service.get_recent_signals(
            tenant_id=self.tenant_id,
            ticker=ticker_filter,
            limit=self.signals_limit
        )
    
    @property
    def champions(self) -> Dict[str, Any]:
        """Get champions data."""
        return self._champions or {}
    
    @property
    def challengers(self) -> Dict[str, Any]:
        """Get challengers data."""
        return self._challengers or {}
    
    @property
    def consensus(self) -> Optional[Any]:
        """Get consensus data."""
        return self._consensus
    
    @property
    def loop_health(self) -> Optional[Any]:
        """Get loop health data."""
        return self._loop_health
    
    @property
    def signals(self) -> List[Any]:
        """Get signals data."""
        return self._signals or []


# ============================================================================
# UI COMPONENTS
# ============================================================================

def render_header():
    """Render the dashboard header."""
    st.title("🚀 Alpha Engine v3.0")
    st.caption("Recursive • Self-learning • Dual Track")


def render_sidebar_controls(state: DashboardState) -> bool:
    """
    Render sidebar controls and update state based on user input.
    
    Args:
        state: Dashboard state instance to update
        
    Returns:
        bool: True if data should be refreshed
    """
    refresh_needed = False
    
    # Data Selection Section
    st.sidebar.header("📊 Data")
    
    tenants = state.service.list_tenants()
    new_tenant_id = st.sidebar.selectbox(
        "Tenant", 
        options=tenants, 
        index=0,
        help="Select the tenant to view data for"
    )
    
    if new_tenant_id != state.tenant_id:
        state.tenant_id = new_tenant_id
        refresh_needed = True
    
    if state.tenant_id:
        all_tickers = state.service.list_tickers(tenant_id=state.tenant_id)
        if all_tickers:
            new_ticker = st.sidebar.selectbox(
                "Ticker", 
                options=all_tickers, 
                index=0,
                help="Select the ticker to view data for"
            )
            if new_ticker != state.ticker:
                state.ticker = new_ticker
                refresh_needed = True
        else:
            state.ticker = None
            st.sidebar.warning("⚠️ No tickers found in DB (predictions).")
    
    # Auto-refresh Section
    st.sidebar.header("🔄 Refresh")
    
    auto_refresh = st.sidebar.checkbox(
        "Auto-refresh", 
        value=True,
        help="Automatically refresh the dashboard"
    )
    
    refresh_ms = st.sidebar.slider(
        "Interval (ms)", 
        min_value=500, 
        max_value=10000, 
        value=DEFAULT_REFRESH_INTERVAL, 
        step=500,
        help="Auto-refresh interval in milliseconds"
    )
    
    if auto_refresh and st_autorefresh is not None:
        st_autorefresh(interval=refresh_ms, key="autorefresh")
    elif auto_refresh:
        st.sidebar.warning("⚠️ Install `streamlit-autorefresh` to enable auto-refresh.")
    
    # Filter Controls Section
    st.sidebar.header("⚙️ Filters")
    
    new_min_predictions = st.sidebar.slider(
        "Min predictions", 
        min_value=0, 
        max_value=50, 
        value=DEFAULT_MIN_PREDICTIONS, 
        step=1,
        help="Minimum number of predictions required for strategies"
    )
    
    new_signals_limit = st.sidebar.slider(
        "Recent signals", 
        min_value=5, 
        max_value=200, 
        value=DEFAULT_SIGNALS_LIMIT, 
        step=5,
        help="Number of recent signals to display"
    )
    
    new_filter_signals = st.sidebar.checkbox(
        "Filter signals to ticker", 
        value=True,
        help="Show signals only for the selected ticker"
    )
    
    # Check if any filter changed
    if (new_min_predictions != state.min_predictions or 
        new_signals_limit != state.signals_limit or
        new_filter_signals != state.filter_signals_to_ticker):
        state.min_predictions = new_min_predictions
        state.signals_limit = new_signals_limit
        state.filter_signals_to_ticker = new_filter_signals
        refresh_needed = True
    
    return refresh_needed


def render_strategy_metric(strategy: Any, strategy_type: str):
    """
    Render a single strategy metric card.
    
    Args:
        strategy: Strategy object with metrics
        strategy_type: Type of strategy (for display)
    """
    if strategy:
        st.metric(
            "strategy_id", 
            strategy.strategy_id, 
            f"cw {strategy.confidence_weight:.2f}"
        )
        st.caption(
            f"win_rate {strategy.win_rate:.2f} • "
            f"alpha {strategy.alpha:.4f} • "
            f"stability {strategy.stability:.2f}"
        )
    else:
        st.metric("strategy_id", "—", "no data")


def render_champions_section(state: DashboardState):
    """Render the champions metrics section."""
    col1, col2, col3, col4 = st.columns(4)
    
    champions = state.champions
    consensus = state.consensus
    
    # Sentiment Champion
    with col1:
        st.subheader("🏆 Champion")
        st.write("Sentiment")
        render_strategy_metric(champions.get("sentiment"), "sentiment")
    
    # Quant Champion
    with col2:
        st.subheader("🏆 Champion")
        st.write("Quant")
        render_strategy_metric(champions.get("quant"), "quant")
    
    # Regime Information
    with col3:
        st.subheader("📈 Regime")
        if consensus:
            st.metric(
                "ACTIVE", 
                consensus.active_regime or "—", 
                f"{consensus.ticker} {arrow(consensus.direction)}"
            )
            hv = consensus.high_vol_strength
            lv = consensus.low_vol_strength
            st.caption(f"HIGH_VOL strength {hv if hv is not None else '—'}")
            st.caption(f"LOW_VOL strength {lv if lv is not None else '—'}")
        else:
            st.metric("ACTIVE", "—", "no consensus")
    
    # Consensus Information
    with col4:
        st.subheader("🤝 Consensus")
        if consensus:
            st.metric(
                "confidence", 
                f"{consensus.confidence:.2f}", 
                f"{arrow(consensus.direction)}"
            )
            st.caption(
                f"total_weight {consensus.total_weight:.2f} • "
                f"participating {consensus.participating_strategies}"
            )
        else:
            st.metric("confidence", "—", "no consensus")


def render_challengers_section(state: DashboardState):
    """Render the challengers section."""
    left, right = st.columns(2)
    
    challengers = state.challengers
    
    with left:
        st.subheader("🥊 Challengers")
        
        st.write("Sentiment")
        sent_chall = challengers.get("sentiment")
        if sent_chall:
            render_strategy_metric(sent_chall, "sentiment")
        else:
            st.caption("No challenger")
        
        st.write("Quant")
        quant_chall = challengers.get("quant")
        if quant_chall:
            render_strategy_metric(quant_chall, "quant")
        else:
            st.caption("No challenger")
    
    with right:
        render_loop_health_section(state.loop_health)


def render_loop_health_section(loop_health: Any):
    """Render the loop health monitoring section."""
    st.subheader("💓 Loop Health")
    
    if not loop_health:
        st.caption("No loop health data available.")
        return
    
    # Last write timestamp
    st.write("Last write")
    st.code(loop_health.last_write_at or "—")
    
    # Processing rates
    st.write("Rates (per min, ~5m window)")
    st.caption(
        f"signals: {loop_health.signal_rate_per_min if loop_health.signal_rate_per_min is not None else '—'}"
    )
    st.caption(
        f"consensus: {loop_health.consensus_rate_per_min if loop_health.consensus_rate_per_min is not None else '—'}"
    )
    st.caption(
        f"learner: {loop_health.learner_update_rate_per_min if loop_health.learner_update_rate_per_min is not None else '—'}"
    )
    
    # Heartbeats
    st.write("Heartbeats")
    if loop_health.heartbeats:
        for hb in loop_health.heartbeats:
            status_emoji = "✅" if hb.status == "healthy" else "⚠️"
            st.write(f"{status_emoji} {hb.loop_type}: {hb.status} ({hb.last_heartbeat_at})")
            if hb.notes:
                st.caption(hb.notes)
    else:
        st.caption("No heartbeats found.")


def render_signals_section(state: DashboardState):
    """Render the recent signals table."""
    st.subheader("📡 Recent Signals")
    
    signals = state.signals
    if not signals:
        st.caption("No signals found.")
        return
    
    # Transform signals for display
    signal_data = [
        {
            "time": s.time,
            "ticker": s.ticker,
            "direction": arrow(s.direction),
            "strategy": s.strategy,
            "regime": s.regime or "",
            "confidence": round(float(s.confidence), 3),
        }
        for s in signals
    ]
    
    st.dataframe(
        signal_data,
        use_container_width=True,
        hide_index=True,
        column_config={
            "time": st.column_config.DatetimeColumn("Time", format="YYYY-MM-DD HH:mm:ss"),
            "ticker": st.column_config.TextColumn("Ticker"),
            "direction": st.column_config.TextColumn("Direction"),
            "strategy": st.column_config.TextColumn("Strategy"),
            "regime": st.column_config.TextColumn("Regime"),
            "confidence": st.column_config.NumberColumn("Confidence", format="%.3f"),
        }
    )


# ============================================================================
# MAIN APPLICATION
# ============================================================================

def main():
    """Modern dashboard with enhanced UI/UX and integrated Plotly charts."""
    
    # Import modern dashboard implementation
    try:
        from app.ui.dashboard_modern import main_modern
        main_modern()
    except ImportError as e:
        st.error(f"Modern dashboard components not available: {e}")
        st.info("Falling back to basic dashboard...")
        
        # Fallback to basic implementation
        service = get_dashboard_service(DEFAULT_DB_PATH)
        state = DashboardState(service)
        
        render_header()
        refresh_needed = render_sidebar_controls(state)
        
        if refresh_needed or not hasattr(state, '_initialized'):
            state.refresh_data()
            state._initialized = True
        
        if not state.tenant_id:
            st.warning("Please select a tenant from the sidebar to view dashboard data.")
            return
        
        render_champions_section(state)
        st.divider()
        render_challengers_section(state)
        st.divider()
        render_signals_section(state)


if __name__ == "__main__":
    main()
