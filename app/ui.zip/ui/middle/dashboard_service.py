from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from app.ui.middle.engine_read_store import (
    ChampionRow,
    ConsensusRow,
    EngineReadStore,
    LoopHealthRow,
    SignalRow,
)


@dataclass(frozen=True)
class ChampionView:
    strategy_id: str
    track: str
    win_rate: float
    alpha: float
    stability: float
    confidence_weight: float


@dataclass(frozen=True)
class ConsensusView:
    ticker: str
    direction: str
    confidence: float
    total_weight: float
    participating_strategies: int
    active_regime: str | None
    high_vol_strength: float | None
    low_vol_strength: float | None


@dataclass(frozen=True)
class LoopHealthView:
    last_write_at: str | None
    signal_rate_per_min: float | None
    consensus_rate_per_min: float | None
    learner_update_rate_per_min: float | None
    heartbeats: list["LoopHeartbeatView"]


@dataclass(frozen=True)
class LoopHeartbeatView:
    loop_type: str
    status: str
    last_heartbeat_at: str
    notes: str | None = None


@dataclass(frozen=True)
class SignalView:
    time: str
    ticker: str
    direction: str
    strategy: str
    regime: str | None
    confidence: float


def arrow(direction: str) -> str:
    d = str(direction).strip().lower()
    if d in ("up", "long", "buy", "1", "+1"):
        return "↑"
    if d in ("down", "short", "sell", "-1"):
        return "↓"
    return "→"


class DashboardService:
    """
    Stable read-model API for Streamlit.

    Architecture:
      Streamlit -> DashboardService -> EngineReadStore (SQL) -> alpha.db

    Rule: UI remains read-only and never queries the DB directly.
    """

    def __init__(self, db_path: str | Path = "data/alpha.db") -> None:
        self.store = EngineReadStore(db_path=db_path)

    def close(self) -> None:
        self.store.close()

    def list_tenants(self) -> list[str]:
        return self.store.list_tenants()

    def list_tickers(self, *, tenant_id: str = "default") -> list[str]:
        return self.store.list_tickers(tenant_id=tenant_id)

    @staticmethod
    def _champion_view(row: ChampionRow) -> ChampionView:
        return ChampionView(
            strategy_id=row.strategy_id,
            track=row.track,
            win_rate=row.win_rate,
            alpha=row.alpha,
            stability=row.stability,
            confidence_weight=row.confidence_weight,
        )

    def get_champions(self, *, tenant_id: str = "default", min_predictions: int = 5) -> dict[str, ChampionView]:
        rows = self.store.get_champions(tenant_id=tenant_id, min_predictions=min_predictions)
        return {k: self._champion_view(v) for k, v in rows.items()}

    def get_challengers(self, *, tenant_id: str = "default", min_predictions: int = 5) -> dict[str, ChampionView]:
        rows = self.store.get_challengers(tenant_id=tenant_id, min_predictions=min_predictions)
        return {k: self._champion_view(v) for k, v in rows.items()}

    @staticmethod
    def _consensus_view(row: ConsensusRow) -> ConsensusView:
        return ConsensusView(
            ticker=row.ticker,
            direction=row.direction,
            confidence=row.confidence,
            total_weight=row.total_weight,
            participating_strategies=row.participating_strategies,
            active_regime=row.active_regime,
            high_vol_strength=row.high_vol_strength,
            low_vol_strength=row.low_vol_strength,
        )

    def get_latest_consensus(self, *, tenant_id: str = "default", ticker: str) -> ConsensusView | None:
        row = self.store.get_latest_consensus(tenant_id=tenant_id, ticker=ticker)
        return None if row is None else self._consensus_view(row)

    @staticmethod
    def _signal_view(row: SignalRow) -> SignalView:
        return SignalView(
            time=row.time,
            ticker=row.ticker,
            direction=row.direction,
            strategy=row.strategy,
            regime=row.regime,
            confidence=row.confidence,
        )

    def get_recent_signals(
        self,
        *,
        tenant_id: str = "default",
        ticker: str | None = None,
        limit: int = 25,
    ) -> list[SignalView]:
        rows = self.store.get_recent_signals(tenant_id=tenant_id, ticker=ticker, limit=limit)
        return [self._signal_view(r) for r in rows]

    @staticmethod
    def _heartbeat_view(row: LoopHealthRow) -> LoopHeartbeatView:
        return LoopHeartbeatView(
            loop_type=row.loop_type,
            status=row.status,
            last_heartbeat_at=row.last_heartbeat_at,
            notes=row.notes,
        )

    def get_loop_health(self, *, tenant_id: str = "default") -> LoopHealthView:
        summary = self.store.get_loop_health(tenant_id=tenant_id)
        return LoopHealthView(
            last_write_at=summary.last_write_at,
            signal_rate_per_min=summary.signal_rate_per_min,
            consensus_rate_per_min=summary.consensus_rate_per_min,
            learner_update_rate_per_min=summary.learner_update_rate_per_min,
            heartbeats=[self._heartbeat_view(hb) for hb in summary.heartbeats],
        )
