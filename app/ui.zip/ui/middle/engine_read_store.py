from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ChampionRow:
    strategy_id: str
    strategy_type: str
    version: str
    mode: str
    track: str
    win_rate: float
    alpha: float
    stability: float
    confidence_weight: float
    prediction_count: int

    regime_strength: dict[str, float] | None = None

@dataclass(frozen=True)
class ConsensusRow:
    ticker: str
    timestamp: str
    direction: str
    confidence: float
    total_weight: float
    participating_strategies: int
    active_regime: str | None
    high_vol_strength: float | None
    low_vol_strength: float | None


@dataclass(frozen=True)
class SignalRow:
    time: str
    ticker: str
    direction: str
    strategy: str
    regime: str | None
    confidence: float


@dataclass(frozen=True)
class LoopHealthRow:
    loop_type: str
    status: str
    last_heartbeat_at: str
    notes: str | None = None


@dataclass(frozen=True)
class LoopHealthSummary:
    last_write_at: str | None
    signal_rate_per_min: float | None
    consensus_rate_per_min: float | None
    learner_update_rate_per_min: float | None
    heartbeats: list[LoopHealthRow]


def _infer_track(strategy_type: str) -> str:
    st = str(strategy_type).strip().lower()
    if st.startswith("text_") or st.startswith("sentiment"):
        return "sentiment"
    if st.startswith("technical_") or st.startswith("baseline_") or st.startswith("quant"):
        return "quant"
    if st == "consensus":
        return "consensus"
    return "unknown"


def _confidence_weight(win_rate: float, stability: float) -> float:
    # Mirrors the intent of ContinuousLearner: win_rate * clamp(stability).
    stab = max(0.1, min(1.0, float(stability)))
    return float(win_rate) * stab


def _parse_ts(value: str | None) -> datetime | None:
    if not value:
        return None
    s = str(value).strip()
    if not s:
        return None
    try:
        s = s.replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


class EngineReadStore:
    """
    Read-only query layer over `alpha.db`.

    DashboardService should call into this store; Streamlit should call only DashboardService.
    """

    def __init__(self, db_path: str | Path = "data/alpha.db") -> None:
        self.db_path = str(db_path)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._ensure_read_model_contract()

    def _ensure_read_model_contract(self) -> None:
        """
        Best-effort, additive schema alignment for UI read models.

        This does not create mock data; it only ensures optional columns exist so
        the UI can rely on a stable contract during rolling upgrades.
        """
        try:
            cols = {str(r["name"]) for r in self.conn.execute("PRAGMA table_info(consensus_signals)").fetchall()}
            for col, ddl in (
                ("direction", "ALTER TABLE consensus_signals ADD COLUMN direction TEXT;"),
                ("confidence", "ALTER TABLE consensus_signals ADD COLUMN confidence REAL;"),
                ("total_weight", "ALTER TABLE consensus_signals ADD COLUMN total_weight REAL;"),
                ("participating_strategies", "ALTER TABLE consensus_signals ADD COLUMN participating_strategies INTEGER;"),
            ):
                if cols and col not in cols:
                    self.conn.execute(ddl)
        except Exception:
            pass

        # Ensure the read-model tables exist (empty is fine; writers populate them).
        try:
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS strategy_weights (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    strategy_id TEXT NOT NULL,
                    win_rate REAL NOT NULL,
                    alpha REAL NOT NULL,
                    stability REAL NOT NULL,
                    confidence_weight REAL NOT NULL,
                    regime_strength_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                """
            )
            self.conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_strategy_weights_strategy ON strategy_weights(tenant_id, strategy_id);"
            )
        except Exception:
            pass

        try:
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS signals (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL,
                    prediction_id TEXT NOT NULL,
                    strategy_id TEXT NOT NULL,
                    ticker TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    track TEXT NOT NULL,
                    regime TEXT,
                    created_at TEXT NOT NULL
                );
                """
            )
            self.conn.execute("CREATE INDEX IF NOT EXISTS idx_signals_ticker_ts ON signals(tenant_id, ticker, timestamp);")
        except Exception:
            pass

        try:
            cols = {str(r["name"]) for r in self.conn.execute("PRAGMA table_info(signals)").fetchall()}
            for col, ddl in (
                ("track", "ALTER TABLE signals ADD COLUMN track TEXT NOT NULL DEFAULT 'unknown';"),
                ("regime", "ALTER TABLE signals ADD COLUMN regime TEXT;"),
            ):
                if cols and col not in cols:
                    self.conn.execute(ddl)
        except Exception:
            pass

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass

    def list_tenants(self) -> list[str]:
        for table in ("predictions", "strategies", "loop_heartbeats", "regime_performance"):
            try:
                rows = self.conn.execute(f"SELECT DISTINCT tenant_id FROM {table} ORDER BY tenant_id").fetchall()
                tenants = [str(r["tenant_id"]) for r in rows if str(r["tenant_id"]).strip()]
                if tenants:
                    return tenants
            except Exception:
                continue
        return ["default"]

    def list_tickers(self, *, tenant_id: str = "default") -> list[str]:
        try:
            rows = self.conn.execute(
                "SELECT DISTINCT ticker FROM predictions WHERE tenant_id = ? ORDER BY ticker",
                (tenant_id,),
            ).fetchall()
            return [str(r["ticker"]) for r in rows if str(r["ticker"]).strip()]
        except Exception:
            return []

    def _strategy_metrics(self, *, tenant_id: str) -> list[ChampionRow]:
        """
        Produces one row per active strategy with joined performance + stability metrics.
        """
        rows = self.conn.execute(
            """
            SELECT
              s.id,
              s.strategy_type,
              s.version,
              s.mode,
              COALESCE(sp.prediction_count, 0) as prediction_count,
              COALESCE(sp.accuracy, 0.0) as win_rate,
              COALESCE(sp.avg_return, 0.0) as alpha,
              COALESCE(ss.stability_score, 0.0) as stability,
              sw.win_rate as sw_win_rate,
              sw.alpha as sw_alpha,
              sw.stability as sw_stability,
              sw.confidence_weight as sw_confidence_weight,
              sw.regime_strength_json as sw_regime_strength_json
            FROM strategies s
            LEFT JOIN strategy_performance sp
              ON sp.tenant_id = s.tenant_id
             AND sp.strategy_id = s.id
             AND sp.horizon = 'ALL'
            LEFT JOIN strategy_stability ss
              ON ss.tenant_id = s.tenant_id
             AND ss.strategy_id = s.id
            LEFT JOIN strategy_weights sw
              ON sw.tenant_id = s.tenant_id
             AND sw.strategy_id = s.id
            WHERE s.tenant_id = ?
              AND s.active = 1
            """,
            (tenant_id,),
        ).fetchall()

        out: list[ChampionRow] = []
        for r in rows:
            stype = str(r["strategy_type"])
            track = _infer_track(stype)
            # Prefer ContinuousLearner-derived weights if present.
            win_rate = float(r["sw_win_rate"]) if r["sw_win_rate"] is not None else float(r["win_rate"])
            alpha = float(r["sw_alpha"]) if r["sw_alpha"] is not None else float(r["alpha"])
            stability = float(r["sw_stability"]) if r["sw_stability"] is not None else float(r["stability"])
            confidence_weight = (
                float(r["sw_confidence_weight"])
                if r["sw_confidence_weight"] is not None
                else _confidence_weight(win_rate, stability)
            )
            regime_strength = None
            if r["sw_regime_strength_json"] is not None:
                try:
                    parsed = json.loads(str(r["sw_regime_strength_json"]))
                    regime_strength = dict(parsed) if isinstance(parsed, dict) else None
                except Exception:
                    regime_strength = None

            out.append(
                ChampionRow(
                    strategy_id=str(r["id"]),
                    strategy_type=stype,
                    version=str(r["version"]),
                    mode=str(r["mode"]),
                    track=track,
                    win_rate=win_rate,
                    alpha=alpha,
                    stability=stability,
                    confidence_weight=confidence_weight,
                    prediction_count=int(r["prediction_count"]),
                    regime_strength=regime_strength,
                )
            )
        return out

    @staticmethod
    def _rank_key(r: ChampionRow) -> tuple[float, float, float, int]:
        return (float(r.confidence_weight), float(r.stability), float(r.alpha), float(r.win_rate), int(r.prediction_count))

    def get_champions(self, *, tenant_id: str = "default", min_predictions: int = 5) -> dict[str, ChampionRow]:
        rows = [r for r in self._strategy_metrics(tenant_id=tenant_id) if r.track in ("sentiment", "quant")]
        out: dict[str, ChampionRow] = {}
        for track in ("sentiment", "quant"):
            pool = [r for r in rows if r.track == track]
            if not pool:
                continue
            eligible = [r for r in pool if r.prediction_count >= int(min_predictions)]
            ranked_pool = eligible if eligible else pool
            out[track] = max(ranked_pool, key=self._rank_key)
        return out

    def get_challengers(self, *, tenant_id: str = "default", min_predictions: int = 5) -> dict[str, ChampionRow]:
        rows = [r for r in self._strategy_metrics(tenant_id=tenant_id) if r.track in ("sentiment", "quant")]
        out: dict[str, ChampionRow] = {}
        for track in ("sentiment", "quant"):
            pool = [r for r in rows if r.track == track]
            if not pool:
                continue
            eligible = [r for r in pool if r.prediction_count >= int(min_predictions)]
            ranked_pool = eligible if eligible else pool
            ranked = sorted(ranked_pool, key=self._rank_key, reverse=True)
            if len(ranked) >= 2:
                out[track] = ranked[1]
        return out

    def _regime_strengths(self, *, tenant_id: str) -> dict[str, float]:
        """
        Best-effort regime strength map from `regime_performance.accuracy` (win rate).
        """
        try:
            rows = self.conn.execute(
                """
                SELECT regime, accuracy
                FROM regime_performance
                WHERE tenant_id = ?
                """,
                (tenant_id,),
            ).fetchall()
        except Exception:
            return {}
        out: dict[str, float] = {}
        for r in rows:
            out[str(r["regime"])] = float(r["accuracy"])
        return out

    def _champion_regime_strength(self, *, tenant_id: str) -> tuple[float | None, float | None]:
        champs = self.get_champions(tenant_id=tenant_id, min_predictions=0)
        strengths: list[dict[str, float]] = []
        for r in champs.values():
            if r.regime_strength:
                strengths.append(r.regime_strength)

        def pick(keys: list[str]) -> float | None:
            vals: list[float] = []
            for s in strengths:
                for k in keys:
                    if k in s:
                        try:
                            vals.append(float(s[k]))
                        except Exception:
                            continue
            if not vals:
                return None
            return max(vals)

        high = pick(["HIGH", "VolatilityRegime.HIGH", "HIGH_VOL"])
        low = pick(["LOW", "VolatilityRegime.LOW", "LOW_VOL"])
        return high, low

    def get_latest_consensus(self, *, tenant_id: str = "default", ticker: str) -> ConsensusRow | None:
        # Prefer materialized consensus_signals (real output fields), fallback to predictions.
        row = None
        try:
            row = self.conn.execute(
                """
                SELECT ticker, created_at as timestamp, direction, confidence, total_weight, participating_strategies, regime
                FROM consensus_signals
                WHERE tenant_id = ? AND ticker = ?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (tenant_id, str(ticker)),
            ).fetchone()
        except Exception:
            row = None

        if row is None:
            try:
                sids = [
                    str(r["id"])
                    for r in self.conn.execute(
                        """
                        SELECT id FROM strategies
                        WHERE tenant_id = ? AND active = 1 AND LOWER(strategy_type) = 'consensus'
                        """,
                        (tenant_id,),
                    ).fetchall()
                ]
            except Exception:
                sids = []
            if not sids:
                return None

            placeholders = ",".join(["?"] * len(sids))
            row = self.conn.execute(
                f"""
                SELECT ticker, timestamp, prediction as direction, confidence, NULL as total_weight, NULL as participating_strategies, regime
                FROM predictions
                WHERE tenant_id = ?
                  AND ticker = ?
                  AND strategy_id IN ({placeholders})
                ORDER BY timestamp DESC
                LIMIT 1
                """,
                (tenant_id, str(ticker), *sids),
            ).fetchone()
            if row is None:
                return None

        # Prefer continuous-learning-derived regime strengths from champions, fallback to global regime_performance.
        high_strength, low_strength = self._champion_regime_strength(tenant_id=tenant_id)
        if high_strength is None or low_strength is None:
            strengths = self._regime_strengths(tenant_id=tenant_id)
            high_strength = high_strength if high_strength is not None else (strengths.get("HIGH") or strengths.get("VolatilityRegime.HIGH"))
            low_strength = low_strength if low_strength is not None else (strengths.get("LOW") or strengths.get("VolatilityRegime.LOW"))

        # Current engine consensus is dual-track, so weights sum to ~1 and participating strategies ~= 2.
        return ConsensusRow(
            ticker=str(row["ticker"]),
            timestamp=str(row["timestamp"]),
            direction=str(row["direction"]),
            confidence=float(row["confidence"]),
            total_weight=float(row["total_weight"]) if row["total_weight"] is not None else 1.0,
            participating_strategies=int(row["participating_strategies"]) if row["participating_strategies"] is not None else 2,
            active_regime=str(row["regime"]) if row["regime"] is not None else None,
            high_vol_strength=float(high_strength) if high_strength is not None else None,
            low_vol_strength=float(low_strength) if low_strength is not None else None,
        )

    def get_recent_signals(
        self,
        *,
        tenant_id: str = "default",
        ticker: str | None = None,
        limit: int = 25,
    ) -> list[SignalRow]:
        limit = max(1, min(int(limit), 500))
        # Prefer first-class signals table; fallback to predictions if it's missing/empty.
        rows = []
        try:
            params: list[Any] = [tenant_id]
            where = ["sig.tenant_id = ?"]
            if ticker:
                where.append("sig.ticker = ?")
                params.append(str(ticker))

            rows = self.conn.execute(
                f"""
                SELECT
                  sig.timestamp as timestamp,
                  sig.ticker as ticker,
                  sig.direction as prediction,
                  sig.confidence as confidence,
                  sig.regime as regime,
                  s.strategy_type as strategy_type,
                  s.version as version
                FROM signals sig
                LEFT JOIN strategies s
                  ON s.tenant_id = sig.tenant_id AND s.id = sig.strategy_id
                WHERE {' AND '.join(where)}
                ORDER BY sig.timestamp DESC
                LIMIT {limit}
                """,
                tuple(params),
            ).fetchall()
        except Exception:
            rows = []

        if not rows:
            params = [tenant_id]
            where = ["p.tenant_id = ?"]
            if ticker:
                where.append("p.ticker = ?")
                params.append(str(ticker))

            rows = self.conn.execute(
                f"""
                SELECT
                  p.timestamp,
                  p.ticker,
                  p.prediction,
                  p.confidence,
                  p.regime,
                  s.strategy_type,
                  s.version
                FROM predictions p
                LEFT JOIN strategies s
                  ON s.tenant_id = p.tenant_id AND s.id = p.strategy_id
                WHERE {' AND '.join(where)}
                ORDER BY p.timestamp DESC
                LIMIT {limit}
                """,
                tuple(params),
            ).fetchall()

        out: list[SignalRow] = []
        for r in rows:
            stype = str(r["strategy_type"] or "unknown")
            ver = str(r["version"] or "")
            out.append(
                SignalRow(
                    time=str(r["timestamp"]),
                    ticker=str(r["ticker"]),
                    direction=str(r["prediction"]),
                    confidence=float(r["confidence"]),
                    strategy=f"{stype}:{ver}" if ver else stype,
                    regime=str(r["regime"]) if r["regime"] is not None else None,
                )
            )
        return out

    def _has_column(self, table: str, column: str) -> bool:
        try:
            cols = {str(r["name"]) for r in self.conn.execute(f"PRAGMA table_info({table})").fetchall()}
            return column in cols
        except Exception:
            return False

    def _latest_write_ts(self, *, tenant_id: str) -> str | None:
        # Prefer system_kv if present (engine writes keys like `live:last_ts`).
        try:
            if self._has_column("system_kv", "k") and self._has_column("system_kv", "v"):
                row = self.conn.execute(
                    "SELECT v FROM system_kv WHERE tenant_id = ? AND k = 'live:last_ts' LIMIT 1",
                    (tenant_id,),
                ).fetchone()
                if row is not None and row["v"] is not None:
                    return str(row["v"])
        except Exception:
            pass

        try:
            row = self.conn.execute(
                "SELECT MAX(timestamp) AS ts FROM predictions WHERE tenant_id = ?",
                (tenant_id,),
            ).fetchone()
            return None if row is None or row["ts"] is None else str(row["ts"])
        except Exception:
            return None

    def _rate_per_min(self, timestamps: list[str], *, window_seconds: int = 300) -> float | None:
        now = datetime.now(timezone.utc)
        cutoff = now.timestamp() - float(window_seconds)
        count = 0
        for ts in timestamps:
            dt = _parse_ts(ts)
            if dt is None:
                continue
            if dt.timestamp() >= cutoff:
                count += 1
        return count / (window_seconds / 60.0)

    def get_loop_health(self, *, tenant_id: str = "default") -> LoopHealthSummary:
        """
        Loop health read model:
        - last write timestamp
        - signal / consensus / learner update rates (best-effort)
        - latest heartbeat per loop type
        """
        try:
            rows = self.conn.execute(
                """
                SELECT loop_type, status, notes, created_at
                FROM loop_heartbeats
                WHERE tenant_id = ?
                ORDER BY created_at DESC
                LIMIT 200
                """,
                (tenant_id,),
            ).fetchall()
        except Exception:
            rows = []

        heartbeats: list[LoopHealthRow] = []
        seen: set[str] = set()
        for r in rows:
            lt = str(r["loop_type"])
            if lt in seen:
                continue
            seen.add(lt)
            heartbeats.append(
                LoopHealthRow(
                    loop_type=lt,
                    status=str(r["status"]),
                    last_heartbeat_at=str(r["created_at"]),
                    notes=str(r["notes"]) if r["notes"] is not None else None,
                )
            )

        # Rates are best-effort; if tables/joins aren't available, return None.
        signal_rate = None
        consensus_rate = None
        learner_rate = None

        # Signals: non-consensus predictions.
        try:
            pred_rows = self.conn.execute(
                """
                SELECT p.timestamp, COALESCE(s.strategy_type, '') as strategy_type
                FROM predictions p
                LEFT JOIN strategies s ON s.tenant_id = p.tenant_id AND s.id = p.strategy_id
                WHERE p.tenant_id = ?
                ORDER BY p.timestamp DESC
                LIMIT 1000
                """,
                (tenant_id,),
            ).fetchall()
            signal_ts = [str(r["timestamp"]) for r in pred_rows if str(r["strategy_type"]).strip().lower() != "consensus"]
            consensus_ts = [str(r["timestamp"]) for r in pred_rows if str(r["strategy_type"]).strip().lower() == "consensus"]
            signal_rate = self._rate_per_min(signal_ts)
            consensus_rate = self._rate_per_min(consensus_ts)
        except Exception:
            pass

        # Learner updates: approximate via strategy_performance.updated_at if available.
        try:
            if self._has_column("strategy_performance", "updated_at"):
                perf_rows = self.conn.execute(
                    """
                    SELECT updated_at
                    FROM strategy_performance
                    WHERE tenant_id = ?
                    ORDER BY updated_at DESC
                    LIMIT 500
                    """,
                    (tenant_id,),
                ).fetchall()
                learner_rate = self._rate_per_min([str(r["updated_at"]) for r in perf_rows])
        except Exception:
            pass

        return LoopHealthSummary(
            last_write_at=self._latest_write_ts(tenant_id=tenant_id),
            signal_rate_per_min=signal_rate,
            consensus_rate_per_min=consensus_rate,
            learner_update_rate_per_min=learner_rate,
            heartbeats=heartbeats,
        )
